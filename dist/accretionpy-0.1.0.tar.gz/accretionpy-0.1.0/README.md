# accretionpy

[![Static Badge](https://img.shields.io/badge/Made%20at%20-%20Code%2FAstro%20-%20blueviolet?link=https%3A%2F%2Fsemaphorep.github.io%2Fcodeastro%2F)](https://semaphorep.github.io/codeastro/)


Package that allows users to determine if accretion onto a BBH 
will be ballistic accretion (common envelope type) or form a circumbinary disk. 

Based on Kummer et al. 2025 (https://www.aanda.org/articles/aa/full_html/2025/01/aa52108-24/aa52108-24.html)

Use this program to determine the type of accretion that will occur based on initial conditions given by the user.

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20870915.svg)](https://doi.org/10.5281/zenodo.20870915)
[![Static Badge](https://img.shields.io/badge/License-MIT-informational?link=https%3A%2F%2Fopensource.org%2Flicense%2Fmit)](https://opensource.org/license/mit)
